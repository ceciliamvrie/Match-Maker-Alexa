module.exports = {
  "aries":"As an aries, you are most compatible with the gemini, leo, the sagittarius, and the aquarius",
  "taurus":"As a taurus, you fit most with the cancer, virgo, the capricorn, and the pisces",
  "gemini":"As a gemini, you are most compatible with the aries, the leo, the libra, and the aquarius",
  "cancer":"As a cancer, you would match nicely with the taurus, virgo, scorpio, and the pisces",
  "leo":"As a leo, you are most compatible with the aries, the gemini, the libra, and the sagittarius",
  "virgo":"As a virgo, you are most compatible with the taurus, the cancer, the scorpio, and the capricorn",
  "libra":"As a libra, you match best with the gemini, the leo, the sagittarius, and the aquarius",
  "scorpio":"As a scorpio, you seem to match best with the cancer, the virgo, the capricorn, and the pisces",
  "sagittarius":"As a sagittarius, you match best with the aries, the gemini, the libra. and the sagittarius",
  "capricorn": "As a capriocorn, you are most compatible with the taurus, the virgo, the scorpio, and the pisces",
  "aquarius": "As an aquarius, you are most compatible with the aries, the gemini, the libra, and the sagittarius",
  "pisces": "As a pisces, you fit best with the taurus, the cancer, the scorpio, and the capricorn"
};
