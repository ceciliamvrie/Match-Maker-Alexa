/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
*/
module.exports {
"Aries":"Passion and fiery heat is your love operating style.",
"Taurus":"Slow and sensual, you know exactly who and what you want.",
"Gemini": "A meeting of the minds is your highest value in love. For you, a stimulating and interesting debate is the best aphrodisiac. ",
"Cancer": "More than anything you want to be able to share your feelings with your partner and feel a sense of connection and understanding. ",
"Leo": "You want to entertain and be entertained in relationships." + "To you, boredom is the kiss of death.",
"Virgo": "Your analytical, thoughtful, and sometimes moody." + "That's why your mate needs to show you just how much they love you.",
"Libra": "Romantic and social, you are always thinking of thoughtful ways to please your partner.",
"Scorpio": "Your emotionally intense nature demands a deep and powerful connection with your love interest." + "Superficiality is a turn-off to you, as you want to dive beneath the surface and explore your partner's more mysterious side.",
"Sagittarius": "Diversity and adventure are a must for you in love. You are enthusiastic and expansive in expressing your affections, but you do best in a relationship where you can have plenty of space to roam free and explore unknown territories.",
"Capricorn": "You are a committed and pragmatic lover and express your affection through actions more than emotions or words. You like to make your partner feel provided for, as if he or she has everything needed to feel comfortable in life.",
"Aquarius": "You are an inventive and stimulating partner who always has something new and interesting to offer to your relationship, just as long as you have the space to be yourself.",
"Pisces": "You have a lot of love to give and appreciate a relationship that allows you to safely open your heart without fear that you will be taken advantage of."
};
