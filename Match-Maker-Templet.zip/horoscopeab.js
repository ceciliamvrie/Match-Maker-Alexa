/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
*/

module.exports = {
"Aries":"You live for passion and a fiery relationship." + "Lovers who don't take for an adventure are sure to get left behind.",
"Taurus":"You live life slow and sensual." + "You know exactly what you want from your partner in a relationship.",
"Gemini": "Finding the right challenge brings you the highest value in love." + "For you, a stimulating and interesting debate makes for the best aphrodisiac.",
"Cancer": "You want to be able to share your feelings more than anything with your partner." + "Your love thrives on the sense of connection and understanding.",
"Leo": "When it comes to relationships, you are both the entertainer and the audience." + "To you, boredom is just as deadly as the kiss of death.",
"Virgo": "You can be analytical, thoughtful, and possible a little moody at times." + "But that doesn't mean you don't deserve love." + "You are just as capable at loving somebody as everyone else.",
"Libra": "As a social romantic, you are always thinking of thoughtful ways to please your partner.",
"Scorpio": "Youre intense nature demands a deep and powerful connection with your love partner." + "Superficiality is a turn-off to you, as you want to dive beneath the surface and explore your partner's mysterious side.",
"Sagittarius": "Adventure is a must for you in love. Youre enthusiastic in expressing your affections, but you do best in a relationship where you can have plenty of space to roam free and explore unknown territories.",
"Capricorn": "To you, actions are larger than words when it comes to expressing your love." + "You like to make your partner feel provided for, as if they have everything needed to feel for comfortable in life.",
"Aquarius": "You are an inventive and stimulating partner who always has something new and interesting to offer in a relationship, just as long as you have enough space to be yourself.",
"Pisces": "You have a lot of love to give" + "Especially in a relationship that allows you to safely open your heart without fear of being taken advantage of."
};
